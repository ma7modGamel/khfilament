<h3
    <?php echo e($attributes->class(['fi-no-notification-title text-sm font-medium text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH /home2/kholood/public_html/employee.kholood.com/vendor/filament/notifications/src/../resources/views/components/title.blade.php ENDPATH**/ ?>