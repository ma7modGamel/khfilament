<input
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
                'type' => 'hidden',
                $applyStateBindingModifiers('wire:model') => $getStatePath(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)
            ->class(['fi-fo-hidden'])); ?>

/>
<?php /**PATH /home2/kholood/public_html/employee.kholood.com/vendor/filament/forms/src/../resources/views/components/hidden.blade.php ENDPATH**/ ?>