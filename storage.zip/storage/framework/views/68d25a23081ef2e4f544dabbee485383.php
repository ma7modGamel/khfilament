<?php echo e($slot); ?>

<?php /**PATH /home2/kholood/public_html/employee.kholood.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>